package kg.own.gitexplorer.View;

public interface ReposViewInterface {
    void filDirPressed(String file, String path);

}
