package kg.own.gitexplorer.Model.Data;

public class Owner {

    final String author, avatar_url;

    public Owner(String author, String avatar_url) {
        this.author = author;
        this.avatar_url = avatar_url;
    }
}
